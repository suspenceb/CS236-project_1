//
// Created by suspe on 9/16/2022.
//

#include "UndefinedAutomaton.h"
void UndefinedAutomaton::S0(const std::string& input) {
    inputRead = 1;
}