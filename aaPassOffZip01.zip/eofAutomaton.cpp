//
// Created by suspe on 9/16/2022.
//

#include "eofAutomaton.h"
void eofAutomaton::S0(const std::string& input) {
    /*if (input[index] == EOF) {
        inputRead = 1;
    }
    else {
        Serr();
    }*/
}